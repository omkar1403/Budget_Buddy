import React from "react";

const Footer = () => {
  return (
    <div className=" bg-white text-light p-5 sticky">
      <h6 className="text-center">All rights reserved &copyright; Omkar</h6>
    </div>
  );
};

export default Footer;
